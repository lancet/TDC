<?php
	
	include($this->_path.'include/config.inc.php');
	return $this->_template('views/list',$editors,false);